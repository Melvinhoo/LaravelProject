<?php $__env->startSection('content'); ?>
    <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                        <?php if($errors->any()): ?>
                        <div class="panel panel-default">
                            <div class="panel-heading">Edit Error</div>
                                <div class="panel-body">
                                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <p> <?php echo e($error); ?> </p>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                              </div>
                            <?php endif; ?>
                    <div class="panel panel-default">
                    <div class="panel-heading">Posted by:  <a class="badge alert-info" href="/profiles/<?php echo e($thread->creator->name); ?>"><?php echo e($thread->creator->name); ?></a>
                        </div>
        
                        <div class="panel-body">
                          <article>
                              <h4>
                                <?php echo e($thread->title); ?> 
                              </h4>
                              <br>
                                  <pre>
                                     <code> <?php echo e($thread->body); ?> </code>
                                  </pre>
                                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $thread)): ?>
                                  <div class="panel-footer">
                                      <form action="<?php echo e($thread->path()); ?>" method="POST" class="ml-a">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

        
                                        <button type="submit" class="btn btn-xs btn-danger">Delete Thread</button>
                                      </form>

                                      <button type="button" class="btn btn-xs btn-success" data-toggle="modal" data-target="#myThread">Edit Thread</button>

                                  </div>

                                      <div class="modal fade" id="myThread" role="dialog">
                                            <div class="modal-dialog">    
                                     
                                              <div class="modal-content">
                                                <div class="modal-header">
                                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                  <h4 class="modal-title">Edit Thread</h4>
                                                </div>
                                                <div class="modal-body">
                                                 <form method="POST" action="<?php echo e($thread->path()); ?>" style="margin-top: 25px;">
                                                     <?php echo method_field('PATCH'); ?>
                                                     <?php echo e(csrf_field()); ?>

                                                     <div class="form-group">
                                                         <label for="title">Title</label> 
                                                         <input name="title" class="form-control <?php echo e($errors->has('title') ? 'is-danger' : ''); ?>" value=" <?php echo e($thread->title); ?> ">
                                                     </div>
                                                     <div class="form-group">
                                                         <textarea name="body" id="body" class="form-control <?php echo e($errors->has('body') ? 'is-danger' : ''); ?>" placeholder="Have something to say?" rows="5"></textarea>
                                                     </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <a class="btn btn-danger" data-dismiss="modal">Close</a>
                                                  <button type="submit" class="btn btn-success">Edit</button>
                                                </div>
                                              </div>
                                             </form>
                                            </div>    
                                        </div>                              
                                     <?php endif; ?>
                                </div>   
                             </div>
                    
                         <?php $__currentLoopData = $thread->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php echo $__env->make('threads.reply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
                              <?php if(auth()->check()): ?>
                              <div class="panel panel-default">
                                    <div class="panel-heading">Reply</div>
                                  <div class="panel-body">
                              <form method="POST" action="<?php echo e($thread->path() . '/replies'); ?>" style="margin-top: 25px;">
                                  <?php echo e(csrf_field()); ?>

                                  <div class="form-group">
                                      <textarea name="body" id="body" class="form-control" placeholder="Have something to say?" rows="5"></textarea>
                                  </div>
              
                                  <button type="submit" class="btn btn-success">Post</button>
                                 </form>
                              </div>
                            </div>
                              <?php else: ?>
                              <p class="text-center"> Please <a href="<?php echo e(route('login')); ?>">Sign in</a> to participate in this discussion.</p>
                          <?php endif; ?>
                          </div>
             
                          <div class="col-md-4">
                                 <div class="panel panel-default">
                                     <div class="panel-heading">Information Thread</div>
                                     <div class="panel-body">
                                         <p>
                                             This thread was published <?php echo e($thread->created_at->diffForHumans()); ?> by
                                             <a href="#"><?php echo e($thread->creator->name); ?></a>, and currently has <?php echo e($thread->replies()->count()); ?> comments.
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
             <?php $__env->stopSection(); ?>
             
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\forum\migrationtest\resources\views/threads/show.blade.php ENDPATH**/ ?>