<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="panel panel-default">
                <div class="panel-heading">Create a new Thread</div>

                <div class="panel-body">
                    <form method="POST" action="<?php echo e(route('threads.index')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                                <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <label for="title">Title:</label>
                            <input type="text" class="form-control <?php echo e($errors->has('title') ? 'is-danger' : ''); ?>" name="title" value="<?php echo e(old('title')); ?>">
                        </div>

                        <div class="form-group">
                             <label for="channel_id">Tag:</label>
                             <select name="channel_id" id="channel_id" class="form-control" required>
                                 <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($channel->id); ?>" <?php echo e(old('channel_id') == $channel->id ? 'selected' : ''); ?>>
                                    <?php echo e($channel->name); ?>

                                 </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                         </div>


                        <div class="form-group">
                          <label for="body">Body:</label>
                          <textarea rows="8" class="form-control <?php echo e($errors->has('body') ? 'is-danger' : ''); ?>" name="body" value="<?php echo e(old('body')); ?>"></textarea>
                        </div>

                        <button type="submit" class="btn btn-success">Publish</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\forum\migrationtest\resources\views/threads/create.blade.php ENDPATH**/ ?>