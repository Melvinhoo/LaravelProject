<?php $__env->startSection('content'); ?>
<div class="container">
     <div class="row">
         <div class="col-md-8">
              <div class="panel panel-default">
                 <div class="panel-heading"><?php echo e($profileUser->name); ?></div>      
                       <div class="panel-body">
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12 col-sm-6 col-md-6">
                                    <div class="well well-sm">
                                        <div class="row">
                                            <div class="col-sm-6 col-md-8">
                                                <h4>
                                                    <?php echo e($profileUser->name); ?></h4>
                                                <p>
                                                    <?php echo e($profileUser->email); ?>

                                                    <br />
                                                    Account Created: <?php echo e($profileUser->created_at->diffForHumans()); ?>

                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
             </div>
         </div>
     </div>
 </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nick/migrationtest/resources/views/profiles/show.blade.php ENDPATH**/ ?>