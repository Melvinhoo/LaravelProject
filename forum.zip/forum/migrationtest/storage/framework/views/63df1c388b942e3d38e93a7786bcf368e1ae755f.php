<?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<div class="panel panel-default">
        <div class="panel-heading">Announcements: <?php echo e($announcement->title); ?> </div>
                   
              <div class="panel-body">
                   <p> Posted by:  <a class="badge alert-info" href="/profiles/<?php echo e($announcement->creator->name); ?>"><?php echo e($announcement->creator->name); ?></a></p>
                    
                    <pre>
                        <code> <?php echo e($announcement->body); ?> </code>
                    </pre>
                    Created: <span class="badge alert-info"><?php echo e($announcement->created_at->diffForHumans()); ?></span>
              </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>

<?php if(Auth::check()): ?>

<?php if(Auth::user()->hasAnyRole(['admin','moderator'])): ?>

 <div class="container">
     <div class="row">
         <div class="col-md-8 offset-md-2">
            <div class="panel panel-default">
               <div class="panel-heading">Create Announcement</div>
               <div class="panel-body">
                <form method="POST" action="/home/create/announcement">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <label for="title">Title:</label>
                          <input type="text" class="form-control <?php echo e($errors->has('title') ? 'is-danger' : ''); ?>" name="title" value="<?php echo e(old('title')); ?>">
                    </div>

                    <div class="form-group">
                            <label for="body">Announcement:</label>
                            <textarea rows="8" class="form-control <?php echo e($errors->has('body') ? 'is-danger' : ''); ?>" name="body" value="<?php echo e(old('body')); ?>"></textarea>
                    </div>

                    <button type="submit" class="btn btn-success">Publish</button>
                </form>
               </div>
            </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
 <?php endif; ?><?php /**PATH C:\xampp\htdocs\forum\migrationtest\resources\views/announcements.blade.php ENDPATH**/ ?>