<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e($thread->title); ?>

                </div>

                <div class="panel-body">
                  <article>
                    <h4>
                       <strong> Posted by: </strong>
                       <a class="badge alert-info" href="/profiles/<?php echo e($thread->creator->name); ?>"><?php echo e($thread->creator->name); ?></a>
                    </h4>
                       <br>
                       <pre>
                        <code class="hljs"> <?php echo e($thread->body); ?> </code>
                     </pre>
                  </article>
                  <br>
                  Created: <span class="badge alert-info"><?php echo e($thread->created_at->diffForHumans()); ?></span>
                  <br>
                  <hr style="border-top: 1px solid #0097ff;">
                  <a href="<?php echo e($thread->path()); ?>" class="btn btn-primary">View Topic</a>
                </a>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-md-4">
          <div class="content-wrap">
              <div class="row">
                <div class="panel panel-default">
                  <div class="panel-heading">Thread Search Bar</div>
                  <div class="panel-body">
                      <form action="/search" method="POST" role="search">
                          <?php echo e(csrf_field()); ?>

                        <div class="row">
                          <div class="col-md-12">
                            <div class="input-group">
                              <input type="text" class="form-control" placeholder="Search" id="txtSearch" name="q">
                              <div class="input-group-btn">
                                <button class="btn btn-primary" type="submit">Submit</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </form>
                  </div>
                </div>
              </div>
          </div>
            <div class="content-wrap">
                <div class="row">
                    <div class="panel panel-default">    
                      <div class="panel-heading">Tags</div>     
                          <div class="panel-body">
                              <ul class="list-group">
                                  <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <a href="/threads/<?php echo e($channel->slug); ?>" class="list-group-item">
                                  <span class="badge">   <?php echo e($channel->threads()->count()); ?> </span>
                                      <?php echo e($channel->name); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                            </ul>
                          </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\forum\migrationtest\resources\views/threads/index.blade.php ENDPATH**/ ?>