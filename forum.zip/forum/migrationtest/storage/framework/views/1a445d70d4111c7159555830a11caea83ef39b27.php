<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/nick/migrationtest/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>