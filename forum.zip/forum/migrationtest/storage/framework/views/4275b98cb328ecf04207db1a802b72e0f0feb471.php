<div class="panel panel-default"  style="margin-top: 25px;">
        <div class="panel-heading">
            <a href="#">
                <?php echo e($reply->owner->name); ?> 
              </a> Said:
             <span class="badge alert-info"><?php echo e($reply->updated_at->diffForHumans()); ?>..</span>
          </div>
          <div class="panel-body">
           <pre>
             <code>  <?php echo e($reply->body); ?> </code>
           </pre>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $reply)): ?>
          <form action="/replies/<?php echo e($reply->id); ?>" method="POST" class="ml-a">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('DELETE')); ?>


              <div class="panel-footer">
              <button type="submit" class="btn btn-xs btn-danger">Delete Reply</button>
           </form>
           <button type="button" class="btn btn-xs btn-success" data-toggle="modal" data-target="#myModal">Edit Reply</button>
          </div>

                    
           <div class="modal fade" id="myModal" role="dialog">
             <div class="modal-dialog">
             
      
               <div class="modal-content">
                 <div class="modal-header">
                   <button type="button" class="close" data-dismiss="modal">&times;</button>
                   <h4 class="modal-title">Edit Reply</h4>
                 </div>
                 <div class="modal-body">
                  <form method="POST" action="/replies/<?php echo e($reply->id); ?>" style="margin-top: 25px;">
                      <?php echo method_field('PATCH'); ?>
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group">
                          <textarea name="body" id="body" class="form-control" placeholder="Have something to say?" rows="5"></textarea>
                      </div>
  
                 </div>
                 <div class="modal-footer">
                     <a class="btn btn-danger" data-dismiss="modal">Close</a>
                   <button type="submit" class="btn btn-success">Edit</button>
                 </div>
               </div>
              </form>
               
             </div>
           </div>
       <?php endif; ?>
      </div>
    </div><?php /**PATH C:\xampp\htdocs\forum\migrationtest\resources\views/threads/reply.blade.php ENDPATH**/ ?>