<?php $__env->startSection('content'); ?>
<div class="container">
     <div class="row">
         <div class="col-md-8">
              <div class="panel panel-default">
                 <div class="panel-heading">Dev Forum Official Announcements</div>
                            
                       <div class="panel-body">
                             Important news and announcements from staff will be posted in this Announcements section and you will also receive an email.
                         </div>
                    </div>

                     <?php echo $__env->make('announcements', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 </div>
             </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\forum\migrationtest\resources\views/home.blade.php ENDPATH**/ ?>