<?php echo e($slot); ?>

<?php /**PATH /Users/nick/migrationtest/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>