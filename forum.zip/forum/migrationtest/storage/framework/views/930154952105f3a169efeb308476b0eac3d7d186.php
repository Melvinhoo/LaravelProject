<?php $__env->startComponent('mail::message'); ?>
# Announcement

You succesfully posted an Announcement

<?php $__env->startComponent('mail::button', ['url' => 'http://127.0.0.1:8000/home']); ?>
Go to Announcement
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/nick/migrationtest/resources/views/emails/announcement-created.blade.php ENDPATH**/ ?>