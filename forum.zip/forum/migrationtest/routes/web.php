<?php

use Illuminate\Support\Facades\Input;
use App\Thread;
use App\User;

Auth::routes(['verify' => true]);

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', 'AnnouncementsController@index');
Route::post('/home/create/announcement', 'AnnouncementsController@store');
Route::get('/threads', 'ThreadsController@index')->name('threads.index');
Route::get('profile/threads', 'ProfileController@index');
Route::get('/profiles/{user}', 'ProfileController@show')->name('profile');
Route::get('threads/create', 'ThreadsController@create')->name('create.create');
Route::get('threads/{channel}/{thread}', 'ThreadsController@show');
Route::post('threads', 'ThreadsController@store');
Route::get('threads/{channel}' , 'ThreadsController@index');
Route::delete('/replies/{reply}', 'RepliesController@destroy')->name('replies.destroy');
Route::delete('threads/{channel}/{thread}', 'ThreadsController@destroy');
Route::patch('threads/{channel}/{thread}', 'ThreadsController@update');
Route::post('/threads/{channel}/{thread}/replies', 'RepliesController@store');
Route::patch('/replies/{reply}', 'RepliesController@update')->name('replies.update');
//zoek functie
Route::any('/search',function(){
    $q = Input::get ( 'q' );
    $thread = Thread::where('title','LIKE','%'.$q.'%')->orwhere('body','LIKE','%'.$q.'%')->get();
    if(count($thread) > 0)
        return view('search')->withDetails($thread)->withQuery ( $q );
    else return view ('search')->withMessage('No Threads found. Try to search again !');
});

