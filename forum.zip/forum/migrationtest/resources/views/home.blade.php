@extends('layouts.app')

@section('content')
<div class="container">
     <div class="row">
         <div class="col-md-8">
              <div class="panel panel-default">
                 <div class="panel-heading">Dev Forum Official Announcements</div>
                            
                       <div class="panel-body">
                             Important news and announcements from staff will be posted in this Announcements section and you will also receive an email.
                         </div>
                    </div>

                     @include ('announcements')
                 </div>
             </div>
        </div>
@endsection
