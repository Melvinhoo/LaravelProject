@component('mail::message')
# Announcement

You succesfully posted an Announcement

@component('mail::button', ['url' => 'http://127.0.0.1:9000/home'])
Go to Announcement
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
