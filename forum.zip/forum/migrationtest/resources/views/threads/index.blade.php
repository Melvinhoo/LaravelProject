@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            @foreach ($threads as $thread) 
            <div class="panel panel-default">
                <div class="panel-heading">{{ $thread->title }}
                </div>

                <div class="panel-body">
                  <article>
                    <h4>
                       <strong> Posted by: </strong>
                       <a class="badge alert-info" href="/profiles/{{ $thread->creator->name }}">{{ $thread->creator->name }}</a>
                    </h4>
                       <br>
                       <pre>
                        <code class="hljs"> {{ $thread->body }} </code>
                     </pre>
                  </article>
                  <br>
                  Created: <span class="badge alert-info">{{ $thread->created_at->diffForHumans()}}</span>
                  <br>
                  <hr style="border-top: 1px solid #0097ff;">
                  <a href="{{ $thread->path() }}" class="btn btn-primary">View Topic</a>
                </a>
              </div>
            </div>
            @endforeach
        </div>
        <div class="col-md-4">
          <div class="content-wrap">
              <div class="row">
                <div class="panel panel-default">
                  <div class="panel-heading">Thread Search Bar</div>
                  <div class="panel-body">
                      <form action="/search" method="POST" role="search">
                          {{ csrf_field() }}
                        <div class="row">
                          <div class="col-md-12">
                            <div class="input-group">
                              <input type="text" class="form-control" placeholder="Search" id="txtSearch" name="q">
                              <div class="input-group-btn">
                                <button class="btn btn-primary" type="submit">Submit</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </form>
                  </div>
                </div>
              </div>
          </div>
            <div class="content-wrap">
                <div class="row">
                    <div class="panel panel-default">    
                      <div class="panel-heading">Tags</div>     
                          <div class="panel-body">
                              <ul class="list-group">
                                  @foreach ($channels as $channel)
                                  <a href="/threads/{{ $channel->slug }}" class="list-group-item">
                                  <span class="badge">   {{ $channel->threads()->count() }} </span>
                                      {{ $channel->name }}
                                 @endforeach
                              </a>
                            </ul>
                          </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
        </div>
      </div>
    </div>
@endsection
