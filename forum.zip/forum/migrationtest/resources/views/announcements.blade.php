@foreach ($announcements as $announcement) 
<div class="panel panel-default">
        <div class="panel-heading">Announcements: {{ $announcement->title }} </div>
                   
              <div class="panel-body">
                   <p> Posted by:  <a class="badge alert-info" href="/profiles/{{ $announcement->creator->name }}">{{ $announcement->creator->name }}</a></p>
                    
                    <pre>
                        <code> {{ $announcement->body }} </code>
                    </pre>
                    Created: <span class="badge alert-info">{{ $announcement->created_at->diffForHumans()}}</span>
              </div>
        </div>
        @endforeach
 </div>

@if (Auth::check())

@if (Auth::user()->hasAnyRole(['admin','moderator']))

 <div class="container">
     <div class="row">
         <div class="col-md-8 offset-md-2">
            <div class="panel panel-default">
               <div class="panel-heading">Create Announcement</div>
               <div class="panel-body">
                <form method="POST" action="/home/create/announcement">
                    {{ csrf_field() }}
                    <div class="form-group">
                        @include ('errors')
                        <label for="title">Title:</label>
                          <input type="text" class="form-control {{ $errors->has('title') ? 'is-danger' : '' }}" name="title" value="{{ old('title') }}">
                    </div>

                    <div class="form-group">
                            <label for="body">Announcement:</label>
                            <textarea rows="8" class="form-control {{ $errors->has('body') ? 'is-danger' : '' }}" name="body" value="{{ old('body') }}"></textarea>
                    </div>

                    <button type="submit" class="btn btn-success">Publish</button>
                </form>
               </div>
            </div>
            </div>
        </div>
    </div>
    @endif
 @endif