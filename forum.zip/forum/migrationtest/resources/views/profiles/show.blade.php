@extends('layouts.app')

@section('content')
<div class="container">
     <div class="row">
         <div class="col-md-8">
              <div class="panel panel-default">
                 <div class="panel-heading">{{ $profileUser->name }}</div>      
                       <div class="panel-body">
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12 col-sm-6 col-md-6">
                                    <div class="well well-sm">
                                        <div class="row">
                                            <div class="col-sm-6 col-md-8">
                                                <h4>
                                                    {{ $profileUser->name }}</h4>
                                                <p>
                                                    {{ $profileUser->email }}
                                                    <br />
                                                    Account Created: {{ $profileUser->created_at->diffForHumans() }}
                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
             </div>
         </div>
     </div>
 </div>
</div>
@endsection
