<?php

namespace App\Listeners;

use App\Mail\AnnouncementCreated as AnnouncementCreatedMail;
use App\Events\AnnouncementCreated;
use Illuminate\support\Facades\Mail;

class SendAnnouncementNotification
{

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  AnnouncementCreated  $event
     * @return void
     */
    public function handle(AnnouncementCreated $event)
    {
        Mail::to($event->announcement->creator->email)->send(
            new AnnouncementCreatedMail($event->announcement)
        );
    }
}
