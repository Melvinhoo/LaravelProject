<?php

namespace App\Http\Controllers;

use App\Channel;
use App\Thread;
use Illuminate\Http\Request;

class ThreadsController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'verified'])->except(['index', 'show']);
    }

    /**
     * Display a listing of the resource.
     *
     * @param Channel $channel
     * @return \Illuminate\Http\Response
     */
    public function index(Channel $channel)
    {
        if ($channel->exists) {
            $threads = $channel->threads()->latest()->get();
        } else {
            $threads = Thread::latest()->get();
        }

        if ($username = request('by')) {

            $user = \App\User::where('name', $username)->firstOrFail();

            $threads->where('user_id', $user->id);
        }

        return view('threads.index', compact('threads'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('threads.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)

    {
        $this->validate($request, [
            'title' => ['required', 'min:3', 'max:255'],
            'body' => ['required', 'min:10'],
            'channel_id' => 'required|exists:channels,id'
        ]);

        $thread = Thread::create([
            
            'user_id' => auth()->id(),

            'channel_id' => request('channel_id'),

            'title' => request('title'),

            'body' => request('body')
            ]);

            return redirect($thread->path());

    }


    /**
     * Display the specified resource.
     *
     * @param $channeId
     * @param  \App\Thread $thread
     * @return \Illuminate\Http\Response
     */
    public function show($channeId, Thread $thread)
    {
        return view('threads.show', compact('thread'));
    }

    /**
     * Update the given thread.
     *
     * @param string $channel
     * @param Thread $thread
     */
    public function update($channel, Thread $thread)
    {
        $this->authorize('update', $thread);

        $thread->update(request()->validate([
            'title' => ['required', 'min:3', 'max:255'],
            'body' => ['required', 'min:10'],
        ]));

        return back();
    }

    /**
     * Delete the given thread.
     *
     * @param        $channel
     * @param Thread $thread
     * @return mixed
     */
    public function destroy($channel, Thread $thread)
    {
        $this->authorize('update', $thread);

        $thread->delete();

        return redirect('/threads');
    }
}
