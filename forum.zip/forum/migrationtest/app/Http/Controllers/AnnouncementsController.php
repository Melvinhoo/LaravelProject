<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Announcement;
// use App\Events\AnnouncementCreated;

class AnnouncementsController extends Controller
{

    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $announcements = Announcement::latest()->get();   //laat de announcements zien
        return view('home', compact('announcements'));
    }

     /**
     * Store a newly created resource in storage.
     *
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)     //create announcement met validation 

    { 
        $this->validate($request, [                             
            'title' => ['required', 'min:3', 'max:255'],
            'body' => ['required', 'min:10'],         
        ]);

        $announcement = Announcement::create([
            
            'user_id' => auth()->id(),

            'title' => request('title'),

            'body' => request('body')
            ]);

        $announcement->save();

        return back();
    }
}
