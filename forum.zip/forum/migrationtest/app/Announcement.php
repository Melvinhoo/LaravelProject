<?php

namespace App;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Announcement extends Model
{

    protected $table = 'announcement';
    

    protected $guarded = [];
    

    public function creator()
    {
      return $this->belongsTo(User::class, 'user_id');
    }


}
